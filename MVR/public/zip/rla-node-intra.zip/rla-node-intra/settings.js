module.exports = {
    // Define a random cookie secret for secure cookie settings
    // Randomly generated at https://www.grc.com/ppp.HTM
    cookieSecret: 'DDCC99B77EBB867647E094FFFE3'
}
