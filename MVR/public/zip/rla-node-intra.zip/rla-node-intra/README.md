# README.md

# Risk-Limiting Audit Manual Cast Vote Record Ballot Entry Tool

### Install
`$ npm install`

### Run
`$ node index.js`
